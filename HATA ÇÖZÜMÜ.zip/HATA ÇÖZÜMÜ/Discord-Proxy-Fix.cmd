@echo off
setlocal
chcp 65001 >nul
title XandyX DPI - Discord Proxy Fix
echo XandyX DPI - Discord Proxy Fix
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Discord-Proxy-Fix.ps1" %*
echo.
echo Kapatmak icin bir tusa bas.
pause >nul
