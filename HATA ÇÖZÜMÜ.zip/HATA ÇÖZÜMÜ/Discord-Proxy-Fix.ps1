﻿#Requires -Version 5.1
<#
.SYNOPSIS
    XandyX DPI - Discord masaustu uygulamasini proxy uzerinden baslatan tek seferlik arac.

.DESCRIPTION
    Discord, Windows sistem proxy'sine bazi surumlerde/ortamlarda uymuyor veya
    sadece acilista okuyor. Bu arac Discord'u Chromium'un --proxy-server bayragiyla
    baslatan bir kisayol olusturur. Boylece tarayicida calisan Discord, masaustu
    uygulamasinda da calisir.

    Varsayilan olarak yeni bir "Discord (XandyX DPI)" kisayolu olusturur ve
    Discord'u bu kisayolla baslatir. Mevcut kisayollari degistirmek icin
    -ReplaceExisting kullan.

.PARAMETER Port
    XandyX DPI proxy portu. Varsayilan: 10808.

.PARAMETER WaitSeconds
    Proxy'nin acilmasini bekleme suresi (saniye). Varsayilan: 60.

.PARAMETER NoStartApp
    XandyX DPI'yi otomatik baslatma ve proxy'nin acilmasini bekleme.

.PARAMETER NoLaunch
    Discord'u simdi baslatma; sadece kisayolu olustur.

.PARAMETER FixStaleProxy
    Proxy kapaliyken sistem proxy'si 127.0.0.1:<Port> adresini gosteriyorsa
    ProxyEnable degerini 0 yap (once yedek alir).

.PARAMETER ReplaceExisting
    Masaustu/Baslat menusundeki mevcut Discord kisayollarini yedekleyip
    proxy'li hale getirir. Ayrica proxysiz "Discord (Normal)" kisayolu olusturur.

.PARAMETER Restore
    Bu aracin olusturdugu/degistirdigi kisayollari geri alir.

.PARAMETER FixStore
    Microsoft Store Discord surumu icin loopback muafiyeti eklemeyi dener.
    Yonetici hakki gerekir.

.PARAMETER DryRun
    Hicbir degisiklik yapmaz; sadece ne yapacagini yazar.

.PARAMETER Yes
    Acilistaki onay sorusunu atlar. Otomatik/sessiz kullanim icin.

.EXAMPLE
    .\Discord-Proxy-Fix.ps1
    Yeni kisayol olustur ve Discord'u proxy ile baslat.

.EXAMPLE
    .\Discord-Proxy-Fix.ps1 -ReplaceExisting -FixStaleProxy
    Mevcut kisayollari degistir ve bozuk sistem proxy'sini temizle.

.EXAMPLE
    .\Discord-Proxy-Fix.ps1 -Restore
    Yapilan degisiklikleri geri al.
#>
[CmdletBinding()]
param(
    [int]$Port = 10808,
    [int]$WaitSeconds = 60,
    [switch]$NoStartApp,
    [switch]$NoLaunch,
    [switch]$FixStaleProxy,
    [switch]$ReplaceExisting,
    [switch]$Restore,
    [switch]$FixStore,
    [switch]$Yes,
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.0.0'

# Turkce karakterlerin konsolda ve yonlendirilen ciktida dogru gorunmesi icin
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

$LocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
$Desktop = [Environment]::GetFolderPath('Desktop')
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$ShortcutName = 'Discord (XandyX DPI).lnk'
$NormalShortcutName = 'Discord (Normal).lnk'

function Write-Title {
    param([string]$Text)
    Write-Host ""
    Write-Host "=== $Text ===" -ForegroundColor Cyan
}

function Write-Step {
    param([string]$Text)
    Write-Host ""
    Write-Host "[$Text]" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Text)
    Write-Host "  [OK] $Text" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Text)
    Write-Host "  [!]  $Text" -ForegroundColor Yellow
}

function Write-Err {
    param([string]$Text)
    Write-Host "  [X]  $Text" -ForegroundColor Red
}

function Write-Info {
    param([string]$Text)
    Write-Host "       $Text" -ForegroundColor Gray
}

function Show-Intro {
    Write-Host ""
    Write-Host "  SORUN" -ForegroundColor Yellow
    Write-Host "    Tarayıcıda Discord açılıyor ama Windows'a kurulu Discord uygulaması"
    Write-Host "    bağlanmıyor. Nedeni: Discord, Windows sistem proxy'sine bazı"
    Write-Host "    sürümlerde uymuyor veya proxy'yi yalnızca açılışta okuyor."
    Write-Host ""
    Write-Host "  ÇÖZÜM" -ForegroundColor Yellow
    Write-Host "    Discord'u Chromium'un --proxy-server bayrağıyla başlatan bir"
    Write-Host "    kısayol oluşturulacak ve Discord bu kısayolla yeniden açılacak."
    Write-Host ""
    Write-Host "  ÖNEMLİ NOTLAR" -ForegroundColor Yellow
    Write-Host "    1) XandyX DPI açık olmalı ve BAŞLAT'a basılmış olmalı (port $Port)."
    Write-Host "    2) Discord tamamen kapatılıp yeniden açılacak."
    Write-Host "       Kaydedilmemiş bir işin varsa önce kaydet."
    Write-Host "    3) Bu araç Discord'un metin/oturum trafiğini proxy'ye sokar."
    Write-Host "       Ses (voice) UDP kullandığı için proxy kapsamı dışındadır."
    Write-Host "    4) Microsoft Store sürümü desteklenmez; normal kurulum gerekir."
    Write-Host "    5) Yönetici hakkı gerekmez (Store loopback muafiyeti hariç)."
    Write-Host "    6) Yapılan değişiklikleri geri almak için: -Restore"
    Write-Host "    7) Antivirüs/SmartScreen uyarısı verebilir; dosyayı güvendiğin"
    Write-Host "       yerden indirdiysen 'Unblock' edip çalıştır."
    if ($ReplaceExisting) {
        Write-Host ""
        Write-Host "    * Mevcut Discord kısayolları yedeklenip proxy'li hale getirilecek." -ForegroundColor Magenta
    }
    if ($FixStaleProxy) {
        Write-Host "    * Bozuk sistem proxy ayarı (ProxyEnable) temizlenecek." -ForegroundColor Magenta
    }
    Write-Host ""
}

function Confirm-Continue {
    if ($Yes -or $DryRun) { return $true }
    if ($Host.Name -ne 'ConsoleHost') { return $true }

    $answer = Read-Host "  Devam etmek için Enter'a bas; iptal için N yaz"
    if ($answer -match '^(n|no|hayir|hayır|iptal)$') { return $false }
    return $true
}

function Test-Port {
    param([int]$P)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect('127.0.0.1', $P, $null, $null)
        $ok = $iar.AsyncWaitHandle.WaitOne(400)
        if (-not $ok) { return $false }
        $client.EndConnect($iar)
        return $true
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Wait-ForProxy {
    param([int]$Seconds = 60)
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        if (Test-Port -P $Port) { return $true }
        Start-Sleep -Milliseconds 1000
    }
    return (Test-Port -P $Port)
}

function Get-DiscordInstall {
    $root = Join-Path $LocalAppData 'Discord'
    $update = Join-Path $root 'Update.exe'
    $apps = @()
    if (Test-Path -LiteralPath $root) {
        $apps = @(Get-ChildItem -LiteralPath $root -Directory -Filter 'app-*' -ErrorAction SilentlyContinue |
            Sort-Object {
                $v = $_.Name -replace '^app-', ''
                try { [version]$v } catch { [version]'0.0.0' }
            } -Descending)
    }

    $appExe = $null
    foreach ($a in $apps) {
        $candidate = Join-Path $a.FullName 'Discord.exe'
        if (Test-Path -LiteralPath $candidate) {
            $appExe = $candidate
            break
        }
    }

    if (-not $appExe) {
        foreach ($p in @(
            (Join-Path $LocalAppData 'Discord\Discord.exe'),
            (Join-Path $env:ProgramFiles 'Discord\Discord.exe')
        )) {
            if (Test-Path -LiteralPath $p) {
                $appExe = $p
                break
            }
        }
    }

    $result = [pscustomobject]@{
        Root      = $root
        UpdateExe = $null
        AppExe    = $appExe
    }
    if (Test-Path -LiteralPath $update) {
        $result.UpdateExe = $update
    }
    return $result
}

function Get-StoreDiscord {
    if (-not (Get-Command Get-AppxPackage -ErrorAction SilentlyContinue)) {
        return $null
    }
    $packages = @(Get-AppxPackage -Name '*Discord*' -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($packages.Count -eq 0) { return $null }
    return $packages[0]
}

function Find-XandyXExe {
    $candidates = New-Object System.Collections.Generic.List[string]
    $candidates.Add((Join-Path $LocalAppData 'Programs\xandyx-dpi\XandyX DPI.exe'))
    $candidates.Add((Join-Path $LocalAppData 'Programs\XandyX DPI\XandyX DPI.exe'))
    $candidates.Add((Join-Path $env:ProgramFiles 'XandyX DPI\XandyX DPI.exe'))
    if (${env:ProgramFiles(x86)}) {
        $candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'XandyX DPI\XandyX DPI.exe'))
    }
    if ($PSScriptRoot) {
        $candidates.Add((Join-Path $PSScriptRoot 'XandyX DPI.exe'))
        $candidates.Add((Join-Path (Split-Path -Parent $PSScriptRoot) 'XandyX DPI.exe'))
    }

    foreach ($p in $candidates) {
        if ($p -and (Test-Path -LiteralPath $p)) { return $p }
    }

    $proc = Get-Process -Name 'XandyX DPI' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path -and (Test-Path -LiteralPath $proc.Path)) {
        return $proc.Path
    }

    $uninstallRoots = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $uninstallRoots) {
        $items = Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue
        foreach ($item in $items) {
            $props = Get-ItemProperty -LiteralPath $item.PSPath -ErrorAction SilentlyContinue
            if ($props.DisplayName -like '*XandyX*') {
                if ($props.DisplayIcon) {
                    $icon = $props.DisplayIcon
                    $icon = $icon -replace '^"', ''
                    $icon = ($icon -split '"')[0]
                    $icon = $icon -replace ',\d+$', ''
                    if (Test-Path -LiteralPath $icon) { return $icon }
                }
                if ($props.InstallLocation) {
                    $candidate = Join-Path $props.InstallLocation 'XandyX DPI.exe'
                    if (Test-Path -LiteralPath $candidate) { return $candidate }
                }
            }
        }
    }
    return $null
}

function New-Shortcut {
    param(
        [string]$Path,
        [string]$TargetPath,
        [string]$Arguments,
        [string]$WorkingDirectory,
        [string]$IconPath
    )

    if ($DryRun) {
        Write-Warn "DRY-RUN kisayol: $Path"
        Write-Info "Hedef: $TargetPath"
        Write-Info "Arguman: $Arguments"
        return
    }

    try {
        $parent = Split-Path -Parent $Path
        if (-not (Test-Path -LiteralPath $parent)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        $shell = New-Object -ComObject WScript.Shell
        $sc = $shell.CreateShortcut($Path)
        $sc.TargetPath = $TargetPath
        $sc.Arguments = $Arguments
        $sc.WorkingDirectory = $WorkingDirectory
        if ($IconPath -and (Test-Path -LiteralPath $IconPath)) {
            $sc.IconLocation = "$IconPath,0"
        }
        $sc.Description = 'Discord - XandyX DPI proxy ile baslat'
        $sc.Save()
        Write-Ok "Kisayol olusturuldu: $Path"
    } catch {
        Write-Err "Kisayol olusturulamadi: $Path"
        Write-Info $_.Exception.Message
    }
}

function Get-ExistingDiscordShortcuts {
    $paths = New-Object System.Collections.Generic.List[string]
    foreach ($p in @(
        (Join-Path $Desktop 'Discord.lnk'),
        (Join-Path $StartMenu 'Discord.lnk'),
        (Join-Path $StartMenu 'Discord Inc\Discord.lnk')
    )) {
        if (Test-Path -LiteralPath $p) { $paths.Add($p) }
    }
    return $paths
}

function Backup-AndPatchShortcut {
    param(
        [string]$Path,
        [string]$TargetPath,
        [string]$Arguments,
        [string]$WorkingDirectory,
        [string]$IconPath
    )

    $backup = "$Path.xandyx-backup"
    if ($DryRun) {
        Write-Warn "DRY-RUN yedeklenecek: $Path -> $backup"
        return
    }

    try {
        if (-not (Test-Path -LiteralPath $backup)) {
            Copy-Item -LiteralPath $Path -Destination $backup -Force
        }
        $shell = New-Object -ComObject WScript.Shell
        $sc = $shell.CreateShortcut($Path)
        $sc.TargetPath = $TargetPath
        $sc.Arguments = $Arguments
        $sc.WorkingDirectory = $WorkingDirectory
        if ($IconPath -and (Test-Path -LiteralPath $IconPath)) {
            $sc.IconLocation = "$IconPath,0"
        }
        $sc.Save()
        Write-Ok "Guncellendi: $Path"
        Write-Info "Yedek: $backup"
    } catch {
        Write-Err "Kisayol guncellenemedi: $Path"
        Write-Info $_.Exception.Message
    }
}

function Restore-All {
    Write-Step 'Geri alma'

    foreach ($p in @(
        (Join-Path $Desktop $ShortcutName),
        (Join-Path $StartMenu $ShortcutName),
        (Join-Path $Desktop $NormalShortcutName),
        (Join-Path $StartMenu $NormalShortcutName)
    )) {
        if (Test-Path -LiteralPath $p) {
            if ($DryRun) {
                Write-Warn "DRY-RUN kaldirilacak: $p"
            } else {
                Remove-Item -LiteralPath $p -Force
                Write-Ok "Kaldirildi: $p"
            }
        }
    }

    $backups = @()
    $backups += @(Get-ChildItem -LiteralPath $Desktop -Filter '*.lnk.xandyx-backup' -ErrorAction SilentlyContinue)
    $backups += @(Get-ChildItem -LiteralPath $StartMenu -Filter '*.lnk.xandyx-backup' -Recurse -ErrorAction SilentlyContinue)

    foreach ($b in $backups) {
        $dest = $b.FullName -replace '\.xandyx-backup$', ''
        if ($DryRun) {
            Write-Warn "DRY-RUN geri yuklenecek: $dest"
        } else {
            Copy-Item -LiteralPath $b.FullName -Destination $dest -Force
            Remove-Item -LiteralPath $b.FullName -Force
            Write-Ok "Geri yuklendi: $dest"
        }
    }

    Write-Info 'Not: Sistem proxy ayarina dokunulmadi.'
}

function Get-ProxySettings {
    $path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
    $v = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
    return [pscustomobject]@{
        Path          = $path
        ProxyEnable   = $v.ProxyEnable
        ProxyServer   = $v.ProxyServer
        ProxyOverride = $v.ProxyOverride
        AutoConfigURL = $v.AutoConfigURL
    }
}

function Invoke-WinInetRefresh {
    try {
        if (-not ('WinInet' -as [type])) {
            Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class WinInet {
    [DllImport("wininet.dll", SetLastError = true)]
    public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);
}
"@
        }
        [void][WinInet]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0)
        [void][WinInet]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0)
    } catch {
        Write-Warn "WinINET bildirimi yapilamadi: $($_.Exception.Message)"
    }
}

function Repair-StaleProxy {
    param($Settings)

    $backupDir = Join-Path $LocalAppData 'XandyX-DPI'
    $backup = Join-Path $backupDir 'proxy-backup.json'

    if ($DryRun) {
        Write-Warn "DRY-RUN: ProxyEnable=0 yapilacak. Yedek: $backup"
        return
    }

    try {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        [pscustomobject]@{
            ProxyEnable   = $Settings.ProxyEnable
            ProxyServer   = $Settings.ProxyServer
            ProxyOverride = $Settings.ProxyOverride
            AutoConfigURL = $Settings.AutoConfigURL
            SavedAt       = (Get-Date).ToString('o')
        } | ConvertTo-Json | Set-Content -LiteralPath $backup -Encoding UTF8

        Set-ItemProperty -LiteralPath $Settings.Path -Name ProxyEnable -Value 0 -Type DWord
        Invoke-WinInetRefresh
        Write-Ok "Sistem proxy'si kapatildi (yedek: $backup)"
    } catch {
        Write-Err "Sistem proxy'si duzeltilemedi: $($_.Exception.Message)"
    }
}

# ---------------------------------------------------------------------------

Write-Title "XandyX DPI - Discord Proxy Fix v$ScriptVersion"
Write-Host "  Port: $Port" -ForegroundColor Gray
if ($ReplaceExisting) {
    Write-Host "  Mod : mevcut kisayollari degistir" -ForegroundColor Gray
} else {
    Write-Host "  Mod : yeni kisayol olustur" -ForegroundColor Gray
}
if ($DryRun) {
    Write-Host "  DRY-RUN: hicbir degisiklik yapilmayacak" -ForegroundColor Yellow
}

if ($Restore) {
    Write-Host ""
    Write-Host "  Geri alma modu: Bu araçla oluşturulan kısayollar kaldırılacak," -ForegroundColor Yellow
    Write-Host "  yedeklenen kısayollar geri yüklenecek. Sistem proxy ayarına dokunulmaz." -ForegroundColor Yellow
    Write-Host ""
    Restore-All
    Write-Title 'Bitti'
    exit 0
}

Show-Intro
if (-not (Confirm-Continue)) {
    Write-Warn 'İptal edildi. Hiçbir değişiklik yapılmadı.'
    exit 0
}

# 1) Proxy kontrolu
Write-Step '1/4 Proxy kontrolu'
$proxyUp = Test-Port -P $Port
if ($proxyUp) {
    Write-Ok "127.0.0.1:$Port dinleniyor."
} else {
    Write-Warn "127.0.0.1:$Port dinlenmiyor."
    $xandyx = Find-XandyXExe
    if ($xandyx -and -not $NoStartApp) {
        $running = Get-Process -Name 'XandyX DPI' -ErrorAction SilentlyContinue
        if (-not $running) {
            if ($DryRun) {
                Write-Warn "DRY-RUN: XandyX DPI baslatilacak: $xandyx"
            } else {
                Write-Info "XandyX DPI baslatiliyor: $xandyx"
                try {
                    Start-Process -FilePath $xandyx | Out-Null
                } catch {
                    Write-Warn "Uygulama baslatilamadi: $($_.Exception.Message)"
                }
            }
        } else {
            Write-Info "XandyX DPI zaten acik."
        }
        if ($DryRun) {
            Write-Warn "DRY-RUN: BAŞLAT'a basilmasi ve proxy'nin acilmasi beklenecek."
        } else {
            Write-Warn "Uygulamada BAŞLAT'a bas. Proxy bekleniyor (en fazla $WaitSeconds sn)..."
            $proxyUp = Wait-ForProxy -Seconds $WaitSeconds
        }
    } elseif ($xandyx) {
        Write-Info "XandyX DPI: $xandyx"
        Write-Info "Uygulamayi acip BAŞLAT'a bas, sonra bu araci tekrar calistir."
    } else {
        Write-Info "XandyX DPI kurulumu bulunamadi. Once uygulamayi ac ve BAŞLAT'a bas."
    }

    if (-not $proxyUp) {
        Write-Warn 'Proxy kapaliyken Discord baslatilmayacak; kisayol yine de olusturulacak.'
        $NoLaunch = $true
    } else {
        Write-Ok "Proxy hazir: 127.0.0.1:$Port"
    }
}

# 2) Sistem proxy kontrolu
Write-Step '2/4 Sistem proxy ayari'
$proxy = Get-ProxySettings
if ($proxy.ProxyEnable -eq 1) {
    if ($proxy.ProxyServer -and $proxy.ProxyServer -match "127\.0\.0\.1:$Port") {
        if ($proxyUp) {
            Write-Ok "Sistem proxy'si XandyX'e yonlu."
        } else {
            Write-Warn "Sistem proxy'si 127.0.0.1:$Port adresini gosteriyor ama proxy kapali."
            if ($FixStaleProxy) {
                Repair-StaleProxy -Settings $proxy
            } else {
                Write-Info 'Bunu duzeltmek icin -FixStaleProxy ile calistir.'
            }
        }
    } else {
        Write-Warn "Sistem proxy'si baska bir adresi gosteriyor: $($proxy.ProxyServer)"
        Write-Info 'Bu arac sistem proxy ayarini degistirmez; Discord kendi bayragiyla calisacak.'
    }
} else {
    Write-Ok "Sistem proxy'si kapali (Discord icin sorun degil)."
}
if ($proxy.AutoConfigURL) {
    Write-Warn "AutoConfigURL (PAC) aktif: $($proxy.AutoConfigURL)"
    Write-Info 'PAC sistem proxy ayarini ezebilir; Discord bayragi yine de onceliklidir.'
}

# 3) Discord kurulumu
Write-Step '3/4 Discord kurulumu'
$discord = Get-DiscordInstall
$store = Get-StoreDiscord
$target = $null
$targetArgs = $null
$workDir = $null
$icon = $null

if ($discord.UpdateExe) {
    $target = $discord.UpdateExe
    $targetArgs = "--processStart Discord.exe --process-start-args=`"--proxy-server=http://127.0.0.1:$Port`""
    $workDir = $discord.Root
    $icon = $discord.AppExe
    Write-Ok "Discord (Squirrel): $($discord.UpdateExe)"
    if ($discord.AppExe) { Write-Info "Uygulama: $($discord.AppExe)" }
} elseif ($discord.AppExe) {
    $target = $discord.AppExe
    $targetArgs = "--proxy-server=http://127.0.0.1:$Port"
    $workDir = Split-Path -Parent $discord.AppExe
    $icon = $discord.AppExe
    Write-Ok "Discord (dogrudan): $($discord.AppExe)"
} elseif ($store) {
    Write-Warn "Microsoft Store surumu: $($store.Name)"
    Write-Info "Paket: $($store.PackageFamilyName)"
    Write-Info "Store surumu 127.0.0.1'e dogrudan erisemez (AppContainer)."
    if ($FixStore) {
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $isAdmin) {
            Write-Err 'Loopback muafiyeti icin yonetici olarak calistir.'
            Write-Info "Komut: CheckNetIsolation LoopbackExempt -a -n=`"$($store.PackageFamilyName)`""
        } elseif ($DryRun) {
            Write-Warn "DRY-RUN: CheckNetIsolation LoopbackExempt -a -n=`"$($store.PackageFamilyName)`""
        } else {
            & "$env:SystemRoot\System32\CheckNetIsolation.exe" LoopbackExempt -a "-n=$($store.PackageFamilyName)" | Out-Null
            Write-Ok 'Loopback muafiyeti eklendi.'
        }
    } else {
        Write-Info 'Duzeltmek icin -FixStore ile yonetici olarak calistir:'
        Write-Info "CheckNetIsolation LoopbackExempt -a -n=`"$($store.PackageFamilyName)`""
    }
    Write-Info 'Oneri: discord.com/download adresinden normal kurulumu kullan.'
    Write-Err 'Store surumu icin proxy bayragi verilemez; kisayol olusturulamadi.'
    exit 2
} else {
    Write-Err 'Discord kurulumu bulunamadi.'
    Write-Info "Discord'u normal yolla kurduktan sonra tekrar dene."
    exit 3
}

# 4) Kisayol + baslatma
Write-Step '4/4 Kisayol ve baslatma'
$newDesktop = Join-Path $Desktop $ShortcutName
$newStart = Join-Path $StartMenu $ShortcutName

New-Shortcut -Path $newDesktop -TargetPath $target -Arguments $targetArgs -WorkingDirectory $workDir -IconPath $icon
if (Test-Path -LiteralPath $StartMenu) {
    New-Shortcut -Path $newStart -TargetPath $target -Arguments $targetArgs -WorkingDirectory $workDir -IconPath $icon
}

if ($ReplaceExisting) {
    $existing = @(Get-ExistingDiscordShortcuts)
    if ($existing.Count -eq 0) {
        Write-Warn 'Degistirilecek mevcut Discord kisayolu bulunamadi.'
    } else {
        foreach ($p in $existing) {
            Backup-AndPatchShortcut -Path $p -TargetPath $target -Arguments $targetArgs -WorkingDirectory $workDir -IconPath $icon
        }
        $normalArgs = if ($discord.UpdateExe) { '--processStart Discord.exe' } else { '' }
        New-Shortcut -Path (Join-Path $Desktop $NormalShortcutName) -TargetPath $target -Arguments $normalArgs -WorkingDirectory $workDir -IconPath $icon
        if (Test-Path -LiteralPath $StartMenu) {
            New-Shortcut -Path (Join-Path $StartMenu $NormalShortcutName) -TargetPath $target -Arguments $normalArgs -WorkingDirectory $workDir -IconPath $icon
        }
    }
}

if ($NoLaunch) {
    Write-Warn 'Baslatma atlandi (-NoLaunch veya proxy kapali).'
} elseif (-not $proxyUp) {
    Write-Warn 'Proxy kapali oldugu icin Discord baslatilmadi.'
} else {
    Write-Info 'Discord kapatiliyor...'
    if (-not $DryRun) {
        Get-Process -Name Discord -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 900
    }

    if ($DryRun) {
        Write-Warn "DRY-RUN: baslatilacak: $target $targetArgs"
    } elseif (Get-Process -Name Discord -ErrorAction SilentlyContinue) {
        Write-Warn "Discord tamamen kapanmadi. Elle kapatip tekrar dene."
    } else {
        try {
            Start-Process -FilePath $target -ArgumentList $targetArgs | Out-Null
            Write-Ok 'Discord baslatildi.'
            Start-Sleep -Seconds 4

            $procs = @(Get-CimInstance Win32_Process -Filter "Name='Discord.exe'" -ErrorAction SilentlyContinue)
            $flagOk = $false
            foreach ($pr in $procs) {
                if ($pr.CommandLine -and $pr.CommandLine -match '--proxy-server') {
                    $flagOk = $true
                    break
                }
            }
            if ($flagOk) {
                Write-Ok 'Discord --proxy-server bayragiyla calisiyor.'
            } else {
                Write-Warn 'Discord sureclerinde bayrak gorunmedi; kisayoldan acmayi dene.'
            }

            $pids = @($procs | ForEach-Object { $_.ProcessId })
            $conns = @()
            if ($pids.Count -gt 0) {
                $conns = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object {
                    $pids -contains $_.OwningProcess -and $_.RemotePort -eq $Port
                })
            }
            if ($conns.Count -gt 0) {
                Write-Ok "Discord trafigi proxy'den geciyor ($($conns.Count) baglanti)."
            } else {
                Write-Warn 'Henuz proxy baglantisi gorunmedi. Discord acildiktan sonra tekrar kontrol edilebilir.'
            }
        } catch {
            Write-Err "Discord baslatilamadi: $($_.Exception.Message)"
        }
    }
}

Write-Title 'Ozet'
Write-Info "Yeni kisayol : $newDesktop"
Write-Info "Baslat menusu: $newStart"
if ($ReplaceExisting) {
    Write-Info "Mevcut Discord kisayollari yedeklendi ve proxy'li hale getirildi."
}
Write-Info "Discord'u bu kisayoldan actiginda trafik XandyX proxy'sinden gecer."
Write-Info "Ses (voice) UDP kullanir; proxy kapsamaz. Ses calismiyorsa TUN/VPN gerekir."
Write-Info "Geri almak icin: -Restore"
Write-Host ""
