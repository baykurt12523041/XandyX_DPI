# Discord Proxy Fix (tek seferlik araç) - v1.0.0

Discord masaüstü uygulaması bazı sürümlerde/ortamlarda Windows sistem proxy'sine
uymuyor veya proxy'yi yalnızca açılışta okuyor. Bu araç Discord'u Chromium'un
`--proxy-server` bayrağıyla başlatan bir kısayol oluşturur.

## Hızlı kullanım

1. XandyX DPI'yı aç ve **BAŞLAT**'a bas (port `10808` dinliyor olmalı).
2. `Discord-Proxy-Fix.cmd` dosyasına çift tıkla.
3. Araç önce önemli notları gösterir ve devam etmek için onay ister.
4. Onayladıktan sonra Discord'u kapatıp proxy'li kısayolla yeniden açar.
5. Bundan sonra Discord'u **Discord (XandyX DPI)** kısayolundan aç.

## Ne yapar?

- `127.0.0.1:10808` proxy'sini kontrol eder.
- Discord'un Squirrel kurulumunu (`%LocalAppData%\Discord\Update.exe`) bulur.
- Masaüstü ve Başlat menüsüne `Discord (XandyX DPI)` kısayolu ekler.
- Kısayolun argümanı:

  ```text
  --processStart Discord.exe --process-start-args="--proxy-server=http://127.0.0.1:10808"
  ```

- Discord'u başlatır ve gerçekten proxy bağlantısı kurulduğunu doğrular.

## Seçenekler

| Parametre | Açıklama |
| --- | --- |
| `-Port 10808` | Proxy portu. |
| `-WaitSeconds 60` | XandyX açık değilse proxy'nin açılmasını bekleme süresi. |
| `-NoStartApp` | XandyX DPI'yı otomatik başlatma ve proxy'yi bekleme. |
| `-NoLaunch` | Discord'u şimdi başlatma, sadece kısayol oluştur. |
| `-ReplaceExisting` | Masaüstü/Başlat menüsündeki mevcut Discord kısayollarını yedekleyip proxy'li hale getirir. Ayrıca proxysiz `Discord (Normal)` kısayolu oluşturur. |
| `-FixStaleProxy` | Proxy kapalıyken `127.0.0.1:10808`'i gösteren bozuk sistem proxy'sini kapatır (önce yedek alır). |
| `-FixStore` | Microsoft Store Discord sürümü için loopback muafiyeti eklemeyi dener (yönetici gerekir). |
| `-Restore` | Bu araçla oluşturulan/değiştirilen kısayolları geri alır. |
| `-Yes` | Açılıştaki onay sorusunu atlar (otomatik/sessiz kullanım). |
| `-DryRun` | Hiçbir değişiklik yapmaz; ne yapacağını yazar. |

Örnekler:

```powershell
# Yeni kısayol + hemen başlat
.\Discord-Proxy-Fix.ps1

# Mevcut kısayolları da değiştir ve bozuk proxy'yi temizle
.\Discord-Proxy-Fix.ps1 -ReplaceExisting -FixStaleProxy

# Sadece kısayol oluştur, Discord'u açma
.\Discord-Proxy-Fix.ps1 -NoLaunch

# Geri al
.\Discord-Proxy-Fix.ps1 -Restore
```

## Sistem proxy yedeği

`-FixStaleProxy` kullanıldığında eski ayarlar şuraya yedeklenir:

```text
%LocalAppData%\XandyX-DPI\proxy-backup.json
```

Geri yüklemek için dosyadaki `ProxyEnable`, `ProxyServer`, `ProxyOverride` ve
`AutoConfigURL` değerlerini `HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`
altına geri yazabilirsin.

## Sınırlar

- **Ses (voice) UDP kullanır.** HTTP CONNECT/SOCKS5 proxy UDP taşımaz. Ses
  genelde DPI tarafından engellenmediği için doğrudan çalışabilir; çalışmıyorsa
  TUN/WinDivert tabanlı bir çözüm veya UDP destekli VPN gerekir.
- **Microsoft Store sürümü** AppContainer içinde çalışır; `127.0.0.1`'e erişmesi
  için loopback muafiyeti gerekir. En sağlıklısı discord.com/download üzerinden
  normal kurulum kullanmaktır.
- **XandyX DPI açık ve BAŞLAT'a basılmış olmalı.** Proxy kapalıyken proxy'li
  kısayol Discord'u başlatamaz.
- Discord güncellemeleri Squirrel kısayolunu yeniden oluşturabilir; bu durumda
  aracı tekrar çalıştırmak yeterlidir.

## Neden tarayıcı çalışıyor da uygulama çalışmıyor?

Tarayıcılar Windows sistem proxy'sine uyar. Discord masaüstü uygulaması ise
Electron/Chromium tabanlı olsa da bazı sürümlerde sistem proxy'sini yok sayar
veya yalnızca açılışta okur. `--proxy-server` bayrağı sistem ayarından bağımsız
olarak Discord'u proxy'ye yönlendirir.
